================
``store`` module
================

.. automodule:: whoosh.store

Classes
=======

.. autoclass:: Storage
    :members:


Exceptions
==========

.. autoexception:: LockError

